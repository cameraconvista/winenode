import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Package } from 'lucide-react';
import { useGestisciOrdini } from '../hooks/useGestisciOrdini';

type TabType = 'inviati' | 'ricevuti' | 'storico';

export default function GestisciOrdiniPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('inviati');
  
  const {
    ordiniInviati,
    ordiniRicevuti,
    ordiniStorico,
    loading
  } = useGestisciOrdini();

  const handleClose = () => {
    navigate('/');
  };

  const getTabCount = (tab: TabType) => {
    switch (tab) {
      case 'inviati':
        return ordiniInviati.length;
      case 'ricevuti':
        return ordiniRicevuti.length;
      case 'storico':
        return ordiniStorico.length;
      default:
        return 0;
    }
  };

  const getCurrentTabData = () => {
    switch (activeTab) {
      case 'inviati':
        return ordiniInviati;
      case 'ricevuti':
        return ordiniRicevuti;
      case 'storico':
        return ordiniStorico;
      default:
        return [];
    }
  };

  const getEmptyMessage = () => {
    switch (activeTab) {
      case 'inviati':
        return {
          title: 'Nessun ordine inviati',
          subtitle: 'Gli ordini inviati appariranno qui'
        };
      case 'ricevuti':
        return {
          title: 'Nessun ordine ricevuti',
          subtitle: 'Gli ordini ricevuti appariranno qui'
        };
      case 'storico':
        return {
          title: 'Nessun ordine nello storico',
          subtitle: 'Lo storico degli ordini apparirà qui'
        };
      default:
        return {
          title: 'Nessun ordine',
          subtitle: 'Gli ordini appariranno qui'
        };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#fff9dc' }}>
        <div className="text-center">
          <div className="text-lg font-medium" style={{ color: '#541111' }}>
            Caricamento ordini...
          </div>
        </div>
      </div>
    );
  }

  const currentData = getCurrentTabData();
  const emptyMessage = getEmptyMessage();

  return (
    <div className="min-h-screen" style={{ background: '#fff9dc' }}>
      {/* Header */}
      <header className="sticky top-0 z-10 p-4 border-b" style={{ 
        background: '#fff9dc', 
        borderColor: '#e2d6aa' 
      }}>
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-bold" style={{ color: '#541111' }}>
            Gestisci Ordini
          </h1>
          <button
            onClick={handleClose}
            className="p-2 rounded-lg transition-colors"
            style={{ color: '#541111' }}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Tabs */}
      <div className="p-4 pb-0">
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('inviati')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors"
            style={{
              background: activeTab === 'inviati' ? '#d4a300' : 'transparent',
              color: activeTab === 'inviati' ? '#fff9dc' : '#541111',
              border: activeTab === 'inviati' ? 'none' : '1px solid #e2d6aa'
            }}
          >
            📤 Inviati ({getTabCount('inviati')})
          </button>
          
          <button
            onClick={() => setActiveTab('ricevuti')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors"
            style={{
              background: activeTab === 'ricevuti' ? '#d4a300' : 'transparent',
              color: activeTab === 'ricevuti' ? '#fff9dc' : '#541111',
              border: activeTab === 'ricevuti' ? 'none' : '1px solid #e2d6aa'
            }}
          >
            📥 Ricevuti ({getTabCount('ricevuti')})
          </button>
          
          <button
            onClick={() => setActiveTab('storico')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors"
            style={{
              background: activeTab === 'storico' ? '#d4a300' : 'transparent',
              color: activeTab === 'storico' ? '#fff9dc' : '#541111',
              border: activeTab === 'storico' ? 'none' : '1px solid #e2d6aa'
            }}
          >
            📋 Storico ({getTabCount('storico')})
          </button>
        </div>
      </div>

      {/* Content */}
      <main className="p-4 pt-0">
        {currentData.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Package 
              className="h-16 w-16 mb-4 opacity-30"
              style={{ color: '#7a4a30' }}
            />
            <h3 className="text-lg font-semibold mb-2" style={{ color: '#541111' }}>
              {emptyMessage.title}
            </h3>
            <p className="text-sm" style={{ color: '#7a4a30' }}>
              {emptyMessage.subtitle}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {currentData.map((ordine) => (
              <div
                key={ordine.id}
                className="p-4 rounded-lg border"
                style={{ background: '#fff2b8', borderColor: '#e2d6aa' }}
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm" style={{ color: '#541111' }}>
                      Ordine #{ordine.id}
                    </h4>
                    <p className="text-xs" style={{ color: '#7a4a30' }}>
                      Fornitore: {ordine.fornitore}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium" style={{ color: '#541111' }}>
                      €{ordine.totale.toFixed(2)}
                    </div>
                    <div className="text-xs" style={{ color: '#7a4a30' }}>
                      {ordine.data}
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between items-center text-xs" style={{ color: '#7a4a30' }}>
                  <span>{ordine.bottiglie} bottiglie</span>
                  <span 
                    className="px-2 py-1 rounded text-xs font-medium"
                    style={{
                      background: ordine.stato === 'completato' ? '#16a34a' : 
                                 ordine.stato === 'in_corso' ? '#d4a300' : '#dc2626',
                      color: '#fff9dc'
                    }}
                  >
                    {ordine.stato}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
