/**
 * Shared Schema - Backward Compatibility Layer
 * Re-esporta tutti gli schemi dai moduli separati per mantenere compatibilità
 * @deprecated Usa import diretti da './schemas/' per nuovi file
 */

// Re-export everything from modular schemas
export * from './schemas';