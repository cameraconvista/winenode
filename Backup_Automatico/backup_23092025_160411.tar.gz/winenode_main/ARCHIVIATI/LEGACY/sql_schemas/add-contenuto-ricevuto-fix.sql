ALTER TABLE ordini ADD COLUMN IF NOT EXISTS contenuto_ricevuto JSONB;
