
// File rimosso - tutte le funzioni sono state migrate in useWineData.ts
