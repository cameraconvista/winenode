import { useState, useRef, useEffect } from 'react';

interface HomeInventoryModalProps {
  isOpen: boolean;
  initialValue: number;
  onConfirm: (value: number) => void;
  onCancel: () => void;
  min?: number;
  max?: number;
}

export default function HomeInventoryModal({
  isOpen,
  initialValue,
  onConfirm,
  onCancel,
  min = 0,
  max = 999
}: HomeInventoryModalProps) {
  const [currentValue, setCurrentValue] = useState(initialValue);
  const [isDragging, setIsDragging] = useState(false);
  const startY = useRef(0);
  const startValue = useRef(0);

  // Sincronizza con initialValue
  useEffect(() => {
    if (isOpen) {
      setCurrentValue(initialValue);
    }
  }, [isOpen, initialValue]);

  // Genera 15 valori consecutivi centrati su currentValue
  const visibleValues = Array.from({ length: 15 }, (_, i) => {
    const value = currentValue - 7 + i;
    return Math.max(min, Math.min(max, value));
  });

  // Gestione drag
  const handleStart = (clientY: number) => {
    setIsDragging(true);
    startY.current = clientY;
    startValue.current = currentValue;
  };

  const handleMove = (clientY: number) => {
    if (!isDragging) return;
    
    const deltaY = startY.current - clientY;
    const steps = Math.round(deltaY / 40);
    const newValue = Math.max(min, Math.min(max, startValue.current + steps));
    
    setCurrentValue(newValue);
  };

  const handleEnd = () => {
    setIsDragging(false);
  };

  // Mouse events
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    handleStart(e.clientY);
  };

  const handleMouseMove = (e: MouseEvent) => {
    handleMove(e.clientY);
  };

  const handleMouseUp = () => {
    handleEnd();
  };

  // Touch events
  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    handleStart(e.touches[0].clientY);
  };

  const handleTouchMove = (e: TouchEvent) => {
    e.preventDefault();
    handleMove(e.touches[0].clientY);
  };

  const handleTouchEnd = () => {
    handleEnd();
  };

  // Event listeners
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', handleTouchEnd);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        document.removeEventListener('touchmove', handleTouchMove);
        document.removeEventListener('touchend', handleTouchEnd);
      };
    }
  }, [isDragging]);

  // ESC key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEsc);
      return () => document.removeEventListener('keydown', handleEsc);
    }
  }, [isOpen, onCancel]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onCancel} />
      
      <div className="relative bg-white rounded-2xl shadow-2xl mx-4 w-full max-w-sm">
        {/* Header */}
        <div className="px-6 py-4 border-b" style={{ borderColor: '#e2d6aa' }}>
          <h3 className="text-lg font-semibold text-center" style={{ color: '#541111' }}>
            Modifica giacenza
          </h3>
        </div>

        {/* Picker */}
        <div className="px-6 py-8">
          <div
            className="relative h-64 flex items-center justify-center cursor-grab select-none"
            style={{ touchAction: 'none', userSelect: 'none', WebkitUserSelect: 'none' }}
            onMouseDown={handleMouseDown}
            onTouchStart={handleTouchStart}
            aria-label={`Giacenza, valore ${currentValue}`}
            role="spinbutton"
            aria-valuenow={currentValue}
            aria-valuemin={min}
            aria-valuemax={max}
          >
            {/* Gradients */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-white via-white/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white via-white/80 to-transparent" />
            </div>

            {/* Center highlight */}
            <div 
              className="absolute top-1/2 left-4 right-4 h-12 -translate-y-1/2 rounded-lg"
              style={{ 
                background: 'rgba(212, 163, 0, 0.1)', 
                borderTop: '2px solid #d4a300', 
                borderBottom: '2px solid #d4a300' 
              }}
            />

            {/* Values */}
            <div className="flex flex-col items-center justify-center h-full overflow-hidden">
              {visibleValues.map((val, index) => {
                const isCenter = index === 7;
                const distance = Math.abs(index - 7);
                const opacity = isCenter ? 1 : Math.max(0.2, 1 - distance * 0.15);
                const scale = isCenter ? 1 : Math.max(0.7, 1 - distance * 0.05);
                
                return (
                  <div
                    key={`${val}-${index}`}
                    className={`text-center transition-all duration-150 cursor-pointer ${
                      isCenter ? 'font-bold' : 'font-normal'
                    }`}
                    style={{
                      opacity,
                      fontSize: isCenter ? '32px' : '24px',
                      lineHeight: '40px',
                      transform: `scale(${scale})`,
                      height: '40px',
                      color: isCenter ? '#541111' : '#7a4a30'
                    }}
                    onClick={() => !isDragging && setCurrentValue(val)}
                  >
                    {val}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="px-6 py-4 border-t flex gap-3" style={{ borderColor: '#e2d6aa' }}>
          <button
            onClick={onCancel}
            className="flex-1 px-4 py-3 rounded-xl font-medium transition-colors"
            style={{ background: '#6b7280', color: '#fff9dc' }}
          >
            Annulla
          </button>
          <button
            onClick={() => onConfirm(currentValue)}
            className="flex-1 px-4 py-3 rounded-xl font-medium transition-colors"
            style={{ background: '#16a34a', color: '#fff9dc' }}
          >
            Conferma
          </button>
        </div>
      </div>
    </div>
  );
}
